****************************************
Please do NOT ask question about LibreTranslate here! We have a forum at https://community.libretranslate.com for questions.

Please open an issue only to report faults and bugs.

For feature requests, please open pull requests directly! We accept all kinds of contributions. If you don't know how to code, you can still provide feedback, but please offer to contribute something (how are you going to help the project develop the feature?)

Remove these lines after reading it
****************************************
